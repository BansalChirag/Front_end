import React from 'react'

export default function Home() {
  return (
    <div>
    <h1 className='home_section'>DatingOne is an app where you can find life Partners of your own Choice.
    Create or Login into your Account to find your matching Partners.</h1>
    </div>
  )
}
