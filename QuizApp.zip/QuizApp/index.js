const Questions = [{
    id: 0,
    q: "1. What year was the first Iron Man movie released, kicking off the Marvel Cinematic Universe?",
    a: [{ text: "2005", isCorrect: false },
        { text: "2008", isCorrect: true },
        { text: "2010", isCorrect: false },
        { text: "2012", isCorrect: false }
    ]

},

{
    id: 1,
    q: "2. What is the name of Thor’s hammer?",
    a: [{ text: "Vanir", isCorrect: false, isSelected: false },
        { text: "Aesir", isCorrect: false },
        { text: "Norn", isCorrect: false },
        { text: "Mjolnir", isCorrect: true }
    ]

},
{
    id: 2,
    q: "3. In the Incredible Hulk, what does Tony tell Thaddeus Ross at the end of the film?",
    a: [{ text: "That he wants to study The Hulk", isCorrect: false },
        { text: "That he knows about S.H.I.E.L.D.", isCorrect: false },
        { text: "That they are putting a team together", isCorrect: true },
        { text: "That Thaddeus owes him money", isCorrect: false }
    ]

},
{
    id: 3,
    q: "4. What is the capital of Afghanistan",
    a: [{ text: "surat", isCorrect: false },
        { text: "vadodara", isCorrect: false },
        { text: "gandhinagar", isCorrect: true },
        { text: "rajkot", isCorrect: false }
    ]

}
,
{
    id: 4,
    q: "5. What is Captain America’s shield made of?",
    a: [{ text: "Adamantium", isCorrect: false },
        { text: "Vibranium", isCorrect: true },
        { text: "Promethium", isCorrect: false },
        { text: "Carbonadium", isCorrect: false }
    ]

}
,
{
    id: 5,
    q: "6. The Flerkens are a race of extremely dangerous aliens that resembles what?",
    a: [{ text: "Cats", isCorrect: true },
        { text: "Ducks", isCorrect: false },
        { text: "Reptiles", isCorrect: false },
        { text: "Raccoons", isCorrect: false }
    ]

}
,
{
    id: 6,
    q: "7. Before becoming Vision, what is the name of Iron Man’s A.I. butler?",
    a: [{ text: "H.O.M.E.R.", isCorrect: false },
        { text: "J.A.R.V.I.S.", isCorrect: true },
        { text: "A.L.F.R.E.D.", isCorrect: false },
        { text: "M.A.R.V.I.N.", isCorrect: false }
    ]
},
{
    id: 7,
    q: "8. What is the real name of the Black Panther?",
    a: [{ text: "T’Challa", isCorrect: true },
        { text: "M’Baku", isCorrect: false },
        { text: "N’Jadaka", isCorrect: false },
        { text: "N’Jobu", isCorrect: false }
    ]
}
,
{
    id: 8,
    q: "9. What is the alien race Loki sends to invade Earth in The Avengers?",
    a: [{ text: "The Chitauri", isCorrect: true },
        { text: "The Skrulls", isCorrect: false },
        { text: "The Kree", isCorrect: false },
        { text: "The Flerkens", isCorrect: false }
    ]
}
,
{
    id: 9,
    q: "10. Who was the last holder of the Space Stone before Thanos claims it for his Infinity Gauntlet?",
    a: [{ text: "The Collector", isCorrect: false },
        { text: "Loki", isCorrect: true },
        { text: "Thor", isCorrect: false },
        { text: "Tony Stark", isCorrect: false }
    ]
}
]



timer();

const one = document.getElementById('one').innerHTML;
const two = document.getElementById('two').innerHTML;
const three = document.getElementById('three').innerHTML;
const four = document.getElementById('four').innerHTML;
const five = document.getElementById('five').innerHTML;
const six = document.getElementById('six').innerHTML;
const seven = document.getElementById('seven').innerHTML;
const eight = document.getElementById('eight').innerHTML;
const nine = document.getElementById('nine').innerHTML;
const ten = document.getElementById('ten').innerHTML;
const next = document.getElementById("next");
const finish_test = document.getElementById('finish');
finish_test.addEventListener('click',()=>{
    let sure = confirm('Are you sure you want to Submit the test?')
    if(sure){
        alert("Your test has been succesfully submitted!.")
        document.getElementById('panel').classList.add('hide');
        document.getElementById('last_text').classList.remove('hide');
    }    

})

const btns = document.querySelectorAll('.btns');

for (var i = 0; i < btns.length; i++) {
    var btn = btns[i];
    btn.addEventListener('click',moveForward)
}
let check1 = true,check2 = false,check3 = false,check4 = false,
check5 = false,check6 = false,check7 = false,check8 = false,
check9 = false,check10 = false


var index = 0;
var idx = 0;

function moveForward(event){
    const id = event.target.innerHTML;    
    if(id==10){
        next.classList.add('hide');
    }
    index = id;
    idx = index-1;
    if(id==one){
        event.target.style.backgroundColor = '#A8E890';   
        iterate(id-1)
        for (var i = 0; i < btns.length; i++) {
            var x = btns[i];
            if(x.innerHTML!== id){
                x.style.backgroundColor = 'white';
            }
        }
        check1 = true;
    }else if(id === two){
        event.target.style.backgroundColor = '#A8E890';  
        iterate(id-1)
        for (var i = 0; i < btns.length; i++) {
            var x = btns[i];
            if(x.innerHTML!== id){
                x.style.backgroundColor = 'white';
            }
        }
        // timer()
        check2 = true;
    }else if(id === three){
        event.target.style.backgroundColor = '#A8E890';   
        iterate(id-1)
        for (var i = 0; i < btns.length; i++) {
            var x = btns[i];
            if(x.innerHTML!== id){
                x.style.backgroundColor = 'white';
            }
        }
        check3 = true
    }else if(id === four){
        event.target.style.backgroundColor = '#A8E890';   
        iterate(id-1)
        for (var i = 0; i < btns.length; i++) {
            var x = btns[i];
            if(x.innerHTML!== id){
                x.style.backgroundColor = 'white';
            }
        }
        check4 = true
    }else if(id === five){
        event.target.style.backgroundColor = '#A8E890';   
        iterate(id-1)
        for (var i = 0; i < btns.length; i++) {
            var x = btns[i];
            if(x.innerHTML!== id){
                x.style.backgroundColor = 'white';
            }
        }
        check5 = true;
    }else if(id === six){
        event.target.style.backgroundColor = '#A8E890';   
        iterate(id-1)
        for (var i = 0; i < btns.length; i++) {
            var x = btns[i];
            if(x.innerHTML!== id){
                x.style.backgroundColor = 'white';
            }
        }
        check6 = true;
    }else if(id === seven){
        event.target.style.backgroundColor = '#A8E890';   
        iterate(id-1)
        for (var i = 0; i < btns.length; i++) {
            var x = btns[i];
            if(x.innerHTML!== id){
                x.style.backgroundColor = 'white';
            }
        }
        check7 = true;
    }else if(id === eight){
        event.target.style.backgroundColor = '#A8E890';   
        iterate(id-1)
        for (var i = 0; i < btns.length; i++) {
            var x = btns[i];
            if(x.innerHTML!== id){
                x.style.backgroundColor = 'white';
            }
        }
        check8 = true;
    }
    else if(id === nine){
        event.target.style.backgroundColor = '#A8E890';   
        iterate(id-1)
        for (var i = 0; i < btns.length; i++) {
            var x = btns[i];
            if(x.innerHTML!== id){
                x.style.backgroundColor = 'white';
            }
        }
        check9 = true;
    }
    else if(id === ten){
        iterate(id-1)
        event.target.style.backgroundColor = '#A8E890';   
        for (var i = 0; i < btns.length; i++) {
            var x = btns[i];
            if(x.innerHTML!== id){
                x.style.backgroundColor = 'white';
            }
        }
        check10 = true;
    }
    check()
}

var start = true;

const options = document.querySelectorAll('.option');
for(var i = 0;i<options.length;i++){
    options[i].addEventListener('click',optionClicked);
}

function optionClicked(event){
    console.log('button is clicked')
        iterate(++idx)
        // clearInterval(downloadTimer)
        colorChangeNext(idx)
        event.target.style.classList.add('click');
}


function iterate(id){
    index = id;
    const question = document.getElementById("question");
    const op1 = document.getElementById("op1");
    const op2 = document.getElementById("op2");
    const op3 = document.getElementById("op3");
    const op4 = document.getElementById("op4");

    question.innerText = Questions[id].q;
    
    op1.innerText = "A.  " + Questions[id].a[0].text;
    op2.innerText = "B.  " + Questions[id].a[1].text;
    op3.innerText = "C.  " + Questions[id].a[2].text;
    op4.innerText = "D.  " + Questions[id].a[3].text;
    
    op1.value = Questions[id].a[0].isCorrect;
    op2.value = Questions[id].a[1].isCorrect;
    op3.value = Questions[id].a[2].isCorrect;
    op4.value = Questions[id].a[3].isCorrect;


    // op1.addEventListener("click", () => {
    //     op1.style.backgroundColor = "green";
    //     op2.style.backgroundColor = "white";
    //     op3.style.backgroundColor = "white";
    //     op4.style.backgroundColor = "white";
    //     selected = op1.value;
    //     // iterate(idx++)
    //     // clearInterval(downloadTimer)
    //     // colorChangeNext(idx)
    // })
  
    // // // Show selection for op2
    // op2.addEventListener("click", () => {
    //     op1.style.backgroundColor = "white";
    //     op2.style.backgroundColor = "green";
    //     op3.style.backgroundColor = "white";
    //     op4.style.backgroundColor = "white";
    //     selected = op2.value;
    //     // iterate(idx++)
    //     // clearInterval(downloadTimer)
    //     // colorChangeNext(idx)
    // })
  
    // // // Show selection for op3
    // op3.addEventListener("click", () => {
    //     op1.style.backgroundColor = "white";
    //     op2.style.backgroundColor = "white";
    //     op3.style.backgroundColor = "green";
    //     op4.style.backgroundColor = "white";
    //     selected = op3.value;
    //     // iterate(idx++)
    //     // clearInterval(downloadTimer)
    //     // colorChangeNext(idx)
    // })
  
    // // // Show selection for op4
    // op4.addEventListener("click", () => {
    //     op1.style.backgroundColor = "white";
    //     op2.style.backgroundColor = "white";
    //     op3.style.backgroundColor = "white";
    //     op4.style.backgroundColor = "green";
    //     selected = op4.value;
    //     // iterate(idx++)
    //     // clearInterval(downloadTimer)
    //     // colorChangeNext(idx)
    // })

    // const evaluate = document.getElementsByClassName("evaluate");
    // evaluate[0].addEventListener("click", () => {
    //     if (selected == "true") {
    //         result[0].innerHTML = "True";
    //         result[0].style.color = "green";
    //     } else {
    //         result[0].innerHTML = "False";
    //         result[0].style.color = "red";
    //     }
    // })


}
    if(start){
        iterate("0");
    }
    
    function colorChangeNext(id){
        if(id==2){
            check2 = true;
        }
        if(id==3){
            check3 = true;
        }
        if(id==4){
            check4 = true;
        }
        if(id==5){
            check5 = true;
        }
        if(id==6){
            check6 = true;
        }
        if(id==7){
            check7 = true;
        }
        if(id==8){
            check8 = true;
        }
        if(id==9){
            check9 = true;
        }
        check()
        if(id==9){
            next.classList.add('hide');
        }   
        btns[id].style.backgroundColor = '#A8E890';

        for(var i = 0;i<id;i++){
            btns[i].style.backgroundColor = 'white';
        }
    }
    var id = 0;
    
    if(check1){
        btns[0].disabled = true;
    }
    function check(){
        if(check2){
                btns[1].disabled = true;
        }
        if(check3){
                btns[2].disabled = true;
        }
        if(check4){
                btns[3].disabled = true;
        }
        if(check5){
                btns[4].disabled = true;
        }
        if(check6){
                btns[5].disabled = true;
        }
        if(check7){
                btns[6].disabled = true;
        }
        if(check8){
                btns[7].disabled = true;
        }
        if(check9){
                btns[8].disabled = true;   
        }
        if(check10){
                btns[9].disabled = true; 
        }
    }

    next.addEventListener("click",()=>{
        if(id<9){
            id++;
            idx++;
            iterate(id);
            console.log("idx  : "+ idx)
            colorChangeNext(idx);
        }
    })

    let circularProgress = document.querySelector(".circular-progress");
    function timer(){
        timeleft = 0;
        let progressBar = document.getElementById("progressBar");
        downloadTimer = setInterval(function(){
        let x = 30 - timeleft;
        if(timeleft == 31){
            clearInterval(downloadTimer);
            alert("Oops! Time's Up")
            document.getElementById('panel').classList.add('hide');
            document.getElementById('last_text').classList.remove('hide');
        }
        if(timeleft<21){
            progressBar.innerHTML = x;
            circularProgress.style.background = `conic-gradient(#A8E890 ${x * 12}deg, white ${x * 9.6}deg)`;
            }else{
                circularProgress.style.background = `conic-gradient(red ${x * 9.6}deg, white ${x * 9.6}deg)`;
            progressBar.innerHTML = "0" + (x);
        }
        timeleft += 1;
        }, 1000);
    }